document.addEventListener('DOMContentLoaded', async function() {
  const video = document.getElementById('video');
  const errorDiv = document.getElementById('error');

  const urlParams = new URLSearchParams(window.location.search);
  const hlsUrl = urlParams.get('hlsUrl');
  const domain = urlParams.get('domain');

  if (!hlsUrl || !domain) {
    showError('Faltan parámetros');
    return;
  }

  if (!domain.startsWith('http')) {
    showError('Dominio inválido');
    return;
  }

  try {
    const hlsOrigin = new URL(hlsUrl).origin;
    const urlFilter = `${hlsOrigin}/*`;

    const cors = {
      id: 1,
      priority: 1,
      action: {
        type: "modifyHeaders",
        requestHeaders: [{
          header: "origin",
          operation: "remove",
        }, {
          header: "referer",
          operation: "remove",
        }]
      },
      condition: {
        urlFilter: urlFilter,
        resourceTypes: ["xmlhttprequest"]
      }
    };

    const agent = {
      id: 2,
      priority: 1,
      action: {
        type: "modifyHeaders",
        requestHeaders: [{
          header: "user-agent",
          operation: "set",
          value: "AppleCoreMedia/1.0.0.25A362 (Macintosh; U; Intel Mac OS X 26_0_1; en_us)"
        }]
      },
      condition: {
        urlFilter: urlFilter,
        resourceTypes: ["xmlhttprequest"]
      }
    };

    await chrome.declarativeNetRequest.updateSessionRules({
      removeRuleIds: [1, 2],
      addRules: [cors, agent]
    });

    if (Hls.isSupported()) {
      const hls = new Hls({
        enableWorker: true
      });

      hls.loadSource(hlsUrl);
      hls.attachMedia(video);
      hls.on(Hls.Events.MANIFEST_PARSED, function() {
        video.play();
      });
      hls.on(Hls.Events.ERROR, function(event, data) {
        if (data.fatal) {
          showError('Error fatal: ' + data.type + ' - ' + data.details);
          hls.destroy();
        }
      });

      window.currentHls = hls;
    } else if (video.canPlayType('application/vnd.apple.mpegurl')) {
      video.src = hlsUrl;
      showError('Soporte nativo: headers no spoofed.');
    } else {
      showError('Navegador no soporta HLS.');
    }
  } catch (error) {
    showError('Error al inicializar: ' + error.message);
  }

  function showError(message) {
    errorDiv.textContent = message;
  }

  window.addEventListener('beforeunload', function() {
    if (window.currentHls) {
      window.currentHls.destroy();
    }
    chrome.declarativeNetRequest.updateSessionRules({
      removeRuleIds: [1, 2]
    }).catch(console.error);
  });
});